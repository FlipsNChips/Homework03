﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DrunkardWalk { 

public class Tunneler : MonoBehaviour
{
    int Percentage;

    float Grabmenge;
    float Bodenfläche;

    GameObject InitializerObject;
    
    GridInitializer gridInitializer;
    int ColumLength;
    int RowLength;

    void Start()
    {
        InitializerObject = GameObject.Find("InitializerObject");
        gridInitializer = InitializerObject.GetComponent("GridInitializer") as GridInitializer;
            ColumLength = gridInitializer.columLength;
            RowLength = gridInitializer.rowLength;
            float usePercentage = Percentage / 100;
        Grabmenge = ColumLength * RowLength * usePercentage;

        StartCoroutine ("Graben");
        
        
      
    }

   IEnumerator Graben()
        {

            while (Percentage == Grabmenge)

            {

                int movedirect;
                movedirect = Random.Range(1, 5);
                Debug.Log (movedirect);

                Vector2 AktuellePosition = gameObject.transform.position;

                if (movedirect == 1)
                {

                    if (AktuellePosition.x >= RowLength)
                    {
                        gameObject.transform.position = new Vector2(AktuellePosition.x + 1, AktuellePosition.y);
                    }

                }

                if (movedirect == 2)
                {
                    if (AktuellePosition.x <= 0)
                    {
                        gameObject.transform.position = new Vector2(AktuellePosition.x - 1, AktuellePosition.y);
                    }
                }

                if (movedirect == 3)
                {
                    if (AktuellePosition.y <= 0)
                    {
                        gameObject.transform.position = new Vector2(AktuellePosition.x, AktuellePosition.y - 1);
                    }
                }

                if (movedirect == 4)
                {
                    if (AktuellePosition.y >= RowLength)
                    {
                        gameObject.transform.position = new Vector2(AktuellePosition.x, AktuellePosition.y + 1);
                    }
                }

                yield return new WaitForSeconds(0.1f);

            }
        }

    void Update()
    {
        
    }
}
}