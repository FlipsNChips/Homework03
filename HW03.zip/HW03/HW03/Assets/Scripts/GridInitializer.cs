﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DrunkardWalk
{

    public class GridInitializer : MonoBehaviour
    {

        public int columLength;
        public int rowLength;
        public GameObject prefab;

        void Start()
        {

            for (int i = 0; i < rowLength; i++)
            {
                for (int h = 0; h < columLength; h++)
                {
                    GameObject wallTile = Instantiate(prefab, transform);

                    wallTile.transform.position = new Vector3(i, h);
                }
            }
        }

    }
}